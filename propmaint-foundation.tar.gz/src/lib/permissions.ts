import { UserRole } from "@prisma/client";

// ============================================================================
// Permission definitions — granular RBAC without a separate permissions table
// ============================================================================

export const PERMISSIONS = {
  // Ticket permissions
  "ticket:create": [UserRole.TENANT, UserRole.MANAGER],
  "ticket:read:own": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
  "ticket:read:all": [UserRole.MANAGER],
  "ticket:read:assigned": [UserRole.STAFF],
  "ticket:assign": [UserRole.MANAGER],
  "ticket:update:status": [UserRole.MANAGER, UserRole.STAFF],
  "ticket:update:priority": [UserRole.MANAGER],
  "ticket:update:cost": [UserRole.MANAGER, UserRole.STAFF],
  "ticket:delete": [UserRole.MANAGER],
  "ticket:close": [UserRole.MANAGER],
  "ticket:verify": [UserRole.MANAGER, UserRole.TENANT],

  // Comment permissions
  "comment:create": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
  "comment:internal": [UserRole.MANAGER, UserRole.STAFF], // Internal notes

  // Team management
  "team:view": [UserRole.MANAGER],
  "team:manage": [UserRole.MANAGER],

  // Analytics
  "analytics:view": [UserRole.MANAGER],

  // Property management
  "property:manage": [UserRole.MANAGER],

  // Notification preferences
  "notification:manage": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
} as const;

export type Permission = keyof typeof PERMISSIONS;

/**
 * Check if a role has a specific permission
 */
export function hasPermission(role: UserRole, permission: Permission): boolean {
  return PERMISSIONS[permission]?.includes(role) ?? false;
}

/**
 * Check if a role has ALL of the specified permissions
 */
export function hasAllPermissions(
  role: UserRole,
  permissions: Permission[]
): boolean {
  return permissions.every((p) => hasPermission(role, p));
}

/**
 * Check if a role has ANY of the specified permissions
 */
export function hasAnyPermission(
  role: UserRole,
  permissions: Permission[]
): boolean {
  return permissions.some((p) => hasPermission(role, p));
}

/**
 * Get all permissions for a role
 */
export function getRolePermissions(role: UserRole): Permission[] {
  return (Object.entries(PERMISSIONS) as [Permission, UserRole[]][])
    .filter(([, roles]) => roles.includes(role))
    .map(([permission]) => permission);
}

// ============================================================================
// SLA Configuration — priority-based deadlines
// ============================================================================

export const SLA_HOURS: Record<string, number> = {
  EMERGENCY: 2,
  URGENT: 24,
  ROUTINE: 72,
  SCHEDULED: 168, // 7 days
};

/**
 * Calculate SLA deadline from creation date and priority
 */
export function calculateSLADeadline(
  createdAt: Date,
  priority: string
): Date {
  const hours = SLA_HOURS[priority] ?? 72;
  return new Date(createdAt.getTime() + hours * 60 * 60 * 1000);
}

// ============================================================================
// Route-based access control map
// ============================================================================

export const ROUTE_PERMISSIONS: Record<string, UserRole[]> = {
  "/dashboard": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
  "/tickets": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
  "/tickets/new": [UserRole.TENANT, UserRole.MANAGER],
  "/analytics": [UserRole.MANAGER],
  "/team": [UserRole.MANAGER],
  "/profile": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
  "/notifications": [UserRole.TENANT, UserRole.MANAGER, UserRole.STAFF],
};
